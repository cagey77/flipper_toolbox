#pragma once

void factory_reset_service_init(void);