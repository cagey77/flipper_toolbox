#pragma once

void cli_uart_init();