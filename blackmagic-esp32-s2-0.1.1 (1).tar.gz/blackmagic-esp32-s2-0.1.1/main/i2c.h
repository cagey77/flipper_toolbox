void i2c_init(void);
void i2c_scan(void);