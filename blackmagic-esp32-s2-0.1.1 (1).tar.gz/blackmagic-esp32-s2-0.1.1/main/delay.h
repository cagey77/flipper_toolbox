#include <stdint.h>

void delay(uint32_t ms);