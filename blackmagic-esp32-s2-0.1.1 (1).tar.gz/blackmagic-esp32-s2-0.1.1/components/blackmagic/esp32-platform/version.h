// for includes only
// we provide the FIRMWARE_VERSION through the build system